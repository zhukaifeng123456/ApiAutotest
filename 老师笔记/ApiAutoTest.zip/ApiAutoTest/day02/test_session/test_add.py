def test_001():
    print("测试add功能1")

def test_002(login):
    print("测试add功能2")

def test_003(login):
    print("测试add功能3")

def test_004(login):
    print("测试add功能4")